import React from "react";

function UserProfile () {
    return (
        <div className="max-w-sm mx-auto bg-white shadow-lg rounded-lg p-6 mt-10">
            <img className="w-24 h-24 rounded-full mx-auto" src="https://i.imgur.com/yXOvdOSs.jpg" alt="profile-photo" />
            <h2 className="text-xl font-semibold text-center mt-4">Hilda Doe</h2>
            <p className="text-gray-600 text-center">Frontend Developer</p>
        </div>
    )
}

export default UserProfile