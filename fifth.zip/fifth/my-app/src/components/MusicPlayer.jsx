import React from "react";

function MusicPlayer(props) {
    return(
        <div className="bg-gray-800 text-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-bold">{props.track.title}</h3>
            <p className="text-gray-400">{props.track.artist}</p>
            <p className="text-gray-400">{props.track.duration}</p>
            <button className="mt-4 bg-purple-500 hover:bg-purple-600 text-white py-2 px-2">play</button>
        </div>
    )
}
export default MusicPlayer