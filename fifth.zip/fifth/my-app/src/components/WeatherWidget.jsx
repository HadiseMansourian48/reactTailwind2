import React from "react";
function WeatherWidget(){
    const tem = 25;
    return(
            <div className="bg-gradient-to-r from-blue-400 to-bblue-600 text-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold">Weather in Rome</h3>
                <p className="text-3xl mt-2">{tem} C</p>
                <p className="text-sm">Sunny</p>
            </div>
    )
}
export default WeatherWidget