import React from "react";

function ToggleSwitch() {
    const isOn = true;
    return (
        <div className="">
            <span className={` p-4 m-4 ${isOn ? 'bg-green-500' : 'bg-red-500'}`}>
                {isOn ? 'On' : 'Off'}
            </span>
            <div></div>
        </div>
    )
}

export default ToggleSwitch