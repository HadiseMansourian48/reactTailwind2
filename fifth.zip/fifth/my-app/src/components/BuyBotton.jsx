import React from "react";

function BuyBotton (){
    return(
        <button className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2">Add to card</button>
    )
}

export default BuyBotton