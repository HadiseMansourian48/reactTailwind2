import React,{useState} from "react";


function Aa(){
    const [state , setState] = useState('Thisssssssssssssss is a simple alert');
    return(
        <>
        <div className="bg-red-50 border-4 border-blue-500 text-blue-700 rounded p-4">
            <p className="font-bold bg-red-50">{'props.title'}</p>
            { <p className="">{state}</p> }
            <button onClick={() => setState('Alert updated.')}
            className="mt-2 bg-blue-500 text-white py-1 px-3 rounded"
            >Change the message</button>
        </div></>
    )
}

export default Aa