import React,{useState} from "react";

function WeatherWidgetIncreseDec(){
    
    // const tem = 25;
    const [tem,setTem] = useState(25);
    return(
            <div className="bg-gradient-to-r from-blue-400 to-bblue-600 text-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-bold">Weather in Rome</h3>
                <p className="text-3xl mt-2">{tem} C</p>
                <p className="text-sm">Sunny</p>
                <div className="mt-4 flex space-x-2">
                    <button 
                    onClick={() => setTem(tem + 1)}
                    className="bg-white text-blue-600 py-1 px-3 rounded">Increase</button>
                    <button
                    onClick={() => setTem(tem - 1)}
                     className="bg-white text-blue-600 py-1 px-3 rounded">Decrease</button>
                </div>
            </div>
    )
}
export default WeatherWidgetIncreseDec