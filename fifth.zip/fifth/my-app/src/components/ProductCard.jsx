import React from "react";
import BuyBotton from "./BuyBotton";

function ProductCard(){
    return(
        <div className="bg-whiet border rounded-lg p-4 shadow-sm m-10">
            <img className="w-full h-48 object-cover rounded-t-lg" src="https://i.imgur.com/yXOvdOSs.jpg" alt="photo"/>
            <h3 className="text-lg font-semibold mt-2">Cool Headphone</h3>
            <p className="text-gray-600">$49.99</p>

            <div className="mt-4"><BuyBotton/></div>

        </div>
    )
}

export default ProductCard