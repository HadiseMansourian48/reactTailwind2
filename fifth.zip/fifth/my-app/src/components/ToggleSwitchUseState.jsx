import React,{useState} from "react";

function ToggleSwitchUseState() {
    const [isOn,setIsOn] = useState(false);
    return (
        <div className="flex items-center p-4">
            <span className="mr-2 text-gray-700">
                {isOn ? 'On' : 'Off'}
            </span>
            <div 
            onClick={() => setIsOn(!isOn)}
            className={`w-12 h-6 flex items-center rounded-full p-1 ${isOn ? "bg-green-400" : "bg-gray-400"}`}>
                <div className={`bg-white w-5 h-5 rounded-full shadow-md transform ${
                isOn ? "translate-x-6" : ''
                }`}>

                </div>
            </div>
        </div>
    )
}

export default ToggleSwitchUseState