import React,{useState} from "react";

function SkillList() {
    const [skills , setSkills] = useState(['Java Script' , "React" , 'Tailwind' , "NextJs"]);
    const [newSkill , setnewSkill] = useState('')
    const addSkill = () => {
        if(newSkill.trim()){
            setSkills([...skills,newSkill])
            setnewSkill('')
        }
    }

    return(
        <div className="p-4">
            <h3 className="text-lg font-bold">Skills</h3>
            <div className="flex flex-wrap gap-2 mt-2">
                {
                    skills ?.map(
                        (skill,index) => 
                        <span key={index} className="bg-blue-100 text-blue-800 text-sm font-bold px-2 py-1 rounded">{skill}</span>
                    )
                }
            </div>
            <input type="text" value={newSkill} onChange={(e) => setnewSkill(e.target.value)} className="p-1 border rounded"/>
            <button onClick={addSkill}>Add Skill</button>
        </div>
    )
}

export default SkillList