import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

import Aa from './components/AlertBox'
import UserProfile from './components/UserProfile'
import WeatherWidget from './components/WeatherWidget'
import ProductCard from './components/ProductCard'
import ToggleSwitch from './components/ToggleSwitch'
import MusicPlayer from './components/MusicPlayer'
import WeatherWidgetIncreseDec from './components/WeatherWidgetIncreaseDec'
import ToggleSwitchUseState from './components/ToggleSwitchUseState'
import MusicPlayerUseState from './components/MusicPlayerUseState'
import SkillList from './components/SkillList'

function App() {
  const [count, setCount] = useState(0);

  const track = {
    title : 'Scape',
    artist : 'Travis Scoot',
    duration : '5:59'
  }
  return (
    <>
      <div className="text-4xl font-bold text-purple-600">
      Tailwind is working!
      </div>
      <Aa title = 'infooo'/>
      <div className="bg-red-50 border-4 border-blue-500 text-blue-700 rounded p-4">
      <p className="font-bold bg-red-50">Info</p>
            <p className="">This is a simple alert box</p>
        </div>
        

        <>
          <UserProfile/>
        </>


        <>
          <WeatherWidget/>
        </>

        <>
          <div className='flex flex-row justify-between'>
            <ProductCard/><ProductCard/><ProductCard/><ProductCard/>
          </div>
        </>

        <>
          <ToggleSwitch/>
        </>  

          <>
            <div className='p-8'>
              <MusicPlayer track = {track}/>
            </div>
          </>



        <>
          <WeatherWidgetIncreseDec/>
        </>

        <>
          <div className='p-8'>
            <ToggleSwitchUseState/>
          </div>
        </>


        <>
            <div className='p-8'>
              <MusicPlayerUseState track = {track}/>
            </div>
          </>

          <>
            <SkillList/>
          </>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )
}

export default App

